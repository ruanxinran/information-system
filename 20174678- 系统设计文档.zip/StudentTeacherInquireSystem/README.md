# StudentTeacherInquireSystem
ASP.NET实现一个简单的学生-教师基本信息查询系统

开发语言：C# & ASP.NET
功能说明：ASP.NET实现的一个简单的学生教师基本信息查询、修改、删除的小系统
开发环境：windows 10 + Visual Studio 2013 + SQL Server 2012
