﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class admin_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //string manpic = "picture/man.jpg";
        //string womenpic = "picture/women.jpg";
        //string man = "男";
        //string women = "女";
        //sqlHelp sqlhelper = new sqlHelp();
        //string updatesql1 = "update teacherInfo set teaPic='" + manpic + "'where teaSex='" + man + "'";
        //string updatesql2 = "update teacherInfo set teaPic='" + womenpic + "'where teaSex='" + women + "'";
        //sqlHelp help = new sqlHelp();
        //help.SqlServerExcute(updatesql1);
        //help.SqlServerExcute(updatesql2);
        //string man = "男";
        //sqlHelp sqlhelper = new sqlHelp();
        //string updatesql1 = "delete studentInfo where stuSex='"+man+"'";
        //sqlhelper.SqlServerExcute(updatesql1);
    }
}